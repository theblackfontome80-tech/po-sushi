/* =========================================================
   PO SUSHI — Données de la carte
   Source : menu officiel (PDF, 19 pages)
   https://qr1.me-qr.com/mobile/pdf/1ce67fa4-29be-4041-b559-2a446fa9fc3c
   Noms, compositions et prix repris tels quels (en DT).
   Photos : menu officiel (assets/menu) et Instagram @sushipo.resto (assets/ig).
   ========================================================= */
window.PO_DATA = {
  categories: [
    { id: "soupes", name: "Soupe miso", jp: "汁", note: "Les entrées",
      items: [
        { name: "Crevettes", price: 13.5 },
        { name: "Poulet", price: 12 },
        { name: "Champignons shiitake", price: 12 },
        { name: "Normal", price: 10 }
      ] },
    { id: "yakitori", name: "Yakitori", jp: "串", note: "Brochettes — les entrées", img: "assets/ig/ig-10.jpg",
      items: [
        { name: "Crunchy Poulet Fromage", price: 16 },
        { name: "Crunchy Boeuf Fromage", price: 19 },
        { name: "Poulet Fromage Grillé", price: 16 },
        { name: "Boeuf Fromage Grillé", price: 19 },
        { name: "Crevettes Grillé", price: 20 },
        { name: "Crunchy Crevettes", price: 20 }
      ] },
    { id: "nems", name: "Nems", jp: "春", note: "Les entrées",
      items: [
        { name: "Crevettes", price: 14 },
        { name: "Poulet", price: 12 },
        { name: "Vegan", price: 10 }
      ] },
    { id: "accompagnements", name: "Accompagnements", jp: "飯",
      items: [
        { name: "Bowl of Riz", price: 8 },
        { name: "Salade au Choux", price: 7 }
      ] },
    { id: "nouilles", name: "Nouilles", jp: "麺", note: "Les plats principaux",
      items: [
        { name: "Vegan", price: 27 },
        { name: "Boeuf", price: 39 },
        { name: "Crevettes", price: 38 },
        { name: "Saumon", price: 41 }
      ] },
    { id: "ramen", name: "Ramen", jp: "拉", note: "Les plats principaux", img: "assets/ig/ig-04.jpg",
      items: [
        { name: "Vegan", price: 30 },
        { name: "Poulet", price: 32 },
        { name: "Crevettes", price: 35 },
        { name: "Saumon", price: 40 }
      ] },
    { id: "fried-rice", name: "Fried Rice", jp: "炒", note: "Les plats principaux", img: "assets/menu/fried-rice.jpg",
      items: [
        { name: "Vegan", price: 26 },
        { name: "Poulet", price: 30 },
        { name: "Boeuf", price: 39 },
        { name: "Crevettes", price: 38 }
      ] },
    { id: "nigiri", name: "Nigiri", jp: "握", img: "assets/menu/nigiri.jpg",
      items: [
        { name: "Suzuki Nigiri", price: 11 },
        { name: "Ebi Sushi", price: 13 },
        { name: "Tuna Nigiri", price: 13 },
        { name: "Salmon Nigiri", price: 13 },
        { name: "Unagi", price: 15 },
        { name: "Bluefin Tuna/Salmon Nigiri", price: 15 }
      ] },
    { id: "gunkan", name: "Gunkan", jp: "軍", img: "assets/menu/gunkan.jpg",
      items: [
        { name: "Tartar Saumon", price: 20 },
        { name: "Tartar Thon", price: 20 },
        { name: "Oeuf Saumon", price: 22 }
      ] },
    { id: "temaki", name: "Temaki", jp: "手", img: "assets/menu/temaki.jpg",
      items: [
        { name: "Temaki Mix", price: 31 },
        { name: "Temaki Saumon", price: 24 },
        { name: "Temaki Crevettes", price: 23 }
      ] },
    { id: "hosomaki", name: "Hosomaki", jp: "細", img: "assets/menu/hosomaki-saumon.jpg",
      items: [
        { name: "Concombre", price: 14 },
        { name: "Daurade", price: 15 },
        { name: "Avocat", price: 16 },
        { name: "Saumon", price: 17 },
        { name: "Tuna", price: 17 },
        { name: "Crevettes", price: 18 }
      ] },
    { id: "sashimi", name: "Sashimi", jp: "刺", note: "Prix pour 3 pièces", img: "assets/menu/feast-1.jpg",
      items: [
        { name: "Salmon Sashimi", price: 15, pcs: "3 pcs" },
        { name: "Tuna Sashimi", price: 15, pcs: "3 pcs" },
        { name: "Suzuki Sashimi", price: 13, pcs: "3 pcs" }
      ] },
    { id: "chirashi", name: "Chirashi", jp: "散", img: "assets/menu/chirashi.jpg",
      items: [
        { name: "Chirachi Poulet", price: 29 },
        { name: "Chirachi Saumon", price: 35 },
        { name: "Chirachi Crevettes", price: 35 },
        { name: "Chirachi All", price: 46 }
      ] },
    { id: "uramaki", name: "Uramaki", jp: "裏", img: "assets/menu/uramaki.jpg",
      items: [
        { name: "Classic", price: 25 },
        { name: "Poulet", price: 20 },
        { name: "Daurade", price: 20 },
        { name: "Crevettes", price: 22 },
        { name: "Tuna", price: 24 }
      ] },
    { id: "avocali", name: "Avocali", jp: "緑", img: "assets/menu/avocali.jpg",
      items: [
        { name: "Poulet", price: 32 },
        { name: "Tuna", price: 36 },
        { name: "Crevettes", price: 36 },
        { name: "Saumon", price: 36 }
      ] },
    { id: "salmon-roll", name: "Salmon Roll", jp: "鮭", img: "assets/ig/ig-07.jpg",
      items: [
        { name: "Avocat Salmon Roll", price: 35 },
        { name: "Crevettes Salmon Roll", price: 38 },
        { name: "Double Salmon Roll", price: 38 },
        { name: "Tataki", price: 38 }
      ] },
    { id: "fried-california", name: "Fried California", jp: "揚", note: "Fried California (Cheddar) · XL (Dose + Sauce Fromage)", img: "assets/menu/fried-california.jpg",
      items: [
        { name: "Poulet", prices: [["Cheddar", 22], ["XL", 27]] },
        { name: "Crevettes", prices: [["Cheddar", 26], ["XL", 31]] },
        { name: "Saumon", prices: [["Cheddar", 27], ["XL", 32]] },
        { name: "Viande", prices: [["Cheddar", 27], ["XL", 32]] }
      ] },
    { id: "crunchy", name: "Crunchy", jp: "衣", note: "6 ou 12 pièces", img: "assets/menu/crunchy.jpg",
      items: [
        { name: "Poulet (Emmental)", prices: [["6 pcs", 21], ["12 pcs", 36]] },
        { name: "Saumon", prices: [["6 pcs", 24], ["12 pcs", 42]] },
        { name: "Saumon Fumé", prices: [["6 pcs", 25], ["12 pcs", 44]] },
        { name: "Crevettes", prices: [["6 pcs", 25], ["12 pcs", 44]] },
        { name: "Viande (Emmental)", prices: [["6 pcs", 23], ["12 pcs", 40]] }
      ] },
    { id: "futomaki", name: "Futomaki", jp: "太", img: "assets/ig/ig-03.jpg",
      items: [
        { name: "Poulet", price: 20 },
        { name: "Veggie", price: 20 },
        { name: "Shrimp Tempura", price: 23 },
        { name: "Saumon", price: 24 },
        { name: "Tuna", price: 24 },
        { name: "Philadelphia", price: 25 }
      ] },
    { id: "special-rolls", name: "Special Rolls", jp: "龍", img: "assets/menu/dragon.jpg",
      items: [
        { name: "Red Dragon Roll", price: 44, desc: "Crevette, saumon, avocat" },
        { name: "Black Dragon Roll", price: 44, desc: "Crevette, fromage, avocat" },
        { name: "Rainbow Roll", price: 40, desc: "Daurade, saumon, avocat, manga, tuna — selon la disponibilité des produits" },
        { name: "Redfin Salmon Roll", price: 39 },
        { name: "Philadelphia", price: 40 },
        { name: "Ebi Blossom", price: 38, desc: "Avocat, crevette, fromage, cucumber" }
      ] },
    { id: "supplements", name: "Suppléments", jp: "添",
      items: [
        { name: "Sauce Salée", price: 2 },
        { name: "Sauce Sucrée", price: 2 },
        { name: "Sauce piquante", price: 2 },
        { name: "Gingembre", price: 2 },
        { name: "Wasabi", price: 2 },
        { name: "Spicy", price: 1 },
        { name: "Cheese", price: 1 }
      ] }
  ],

  /* SUSHI FEAST — plateaux à partager */
  platters: [
    { name: "Sushi Starter", pieces: 12, price: 33, img: "assets/menu/feast-2.jpg",
      items: ["2 Nigiri", "6 Hosomaki", "4 Uramaki"] },
    { name: "Tokyo Mix", pieces: 18, price: 55, img: "assets/menu/feast-3.jpg",
      items: ["2 Nigiri", "6 Hosomaki", "4 Uramaki", "6 Crunchy"] },
    { name: "Salmon Lover", pieces: 19, price: 64, img: "assets/ig/ig-06.jpg",
      items: ["4 Salmon Rolls", "2 Nigiri", "3 Sashimi", "4 Uramaki", "6 Hosomaki"] },
    { name: "Dragon Selection", pieces: 25, price: 75, img: "assets/ig/ig-05.jpg",
      items: ["2 Nigiri", "3 Sashimi", "6 Crunchy", "4 Uramaki", "4 Dragon Rolls", "6 Hosomaki"] },
    { name: "Tokyo Premium", pieces: 37, price: 120, img: "assets/menu/feast-5.jpg",
      items: ["4 Nigiri", "3 Sashimi", "6 Hosomaki", "8 Uramaki", "6 Crunchy", "4 Dragon Rolls", "6 Fried California"] },
    { name: "Sushi Experience", pieces: 50, price: 160, img: "assets/menu/feast-4.jpg",
      items: ["4 Nigiri", "6 Sashimi", "6 Hosomaki", "8 Uramaki", "6 Crunchy", "4 Salmon Rolls", "4 Dragon Rolls", "6 Futomaki", "6 Fried California"] },
    { name: "Royal Sushi", pieces: 52, price: 175, img: "assets/menu/feast-6.jpg",
      items: ["4 Nigiri", "6 Sashimi", "6 Hosomaki", "8 Uramaki", "6 Crunchy", "4 Salmon Rolls", "4 Dragon Rolls", "6 Futomaki", "6 Fried California", "2 Temaki"] },
    { name: "Sushi Festival", pieces: 52, price: 175, img: "assets/menu/feast-7.jpg",
      items: ["4 Nigiri", "6 Sashimi", "6 Hosomaki", "8 Uramaki", "12 Crunchy", "4 Salmon Rolls", "4 Dragon Rolls", "6 Futomaki", "10 Fried California", "2 Temaki"] },
    { name: "Imperial Selection", pieces: 69, price: 195, img: "assets/ig/ig-02.jpg",
      items: ["8 Nigiri", "9 Sashimi", "6 Hosomaki", "8 Uramaki", "12 Crunchy", "8 Salmon Rolls", "4 Dragon Rolls", "6 Futomaki", "6 Fried California", "2 Temaki"] },
    { name: "Grand Sushi Experience", pieces: 83, price: 225, img: "assets/menu/feast-8.jpg",
      items: ["8 Nigiri", "9 Sashimi", "12 Hosomaki", "8 Uramaki", "12 Crunchy", "8 Salmon Rolls", "8 Dragon Rolls", "6 Futomaki", "10 Fried California", "2 Temaki"] }
  ],

  /* Tapis kaiten — sélection de plats réels de la carte.
     tier = couleur de l'assiette selon le prix (1 : < 15 DT … 5 : 50 DT et +) */
  belt: [
    { id: "salmon-nigiri", name: "Salmon Nigiri", price: "13 DT", tier: 1, category: "Nigiri", categoryId: "nigiri", image: "assets/belt/nigiri.jpg",
      description: "Saumon sur riz vinaigré, façonné à la main.", details: ["Nigiri", "Saumon"] },
    { id: "hosomaki-saumon", name: "Hosomaki Saumon", price: "17 DT", tier: 2, category: "Hosomaki", categoryId: "hosomaki", image: "assets/belt/hosomaki-saumon.jpg",
      description: "Le maki fin, roulé dans la feuille de nori.", details: ["Hosomaki", "Saumon"] },
    { id: "gunkan-oeuf", name: "Gunkan Oeuf Saumon", price: "22 DT", tier: 2, category: "Gunkan", categoryId: "gunkan", image: "assets/belt/gunkan.jpg",
      description: "Une bande de nori garnie d'œufs de saumon.", details: ["Gunkan", "Œufs de saumon"] },
    { id: "temaki-crevettes", name: "Temaki Crevettes", price: "23 DT", tier: 2, category: "Temaki", categoryId: "temaki", image: "assets/belt/temaki.jpg",
      description: "Le cornet de nori roulé à la main.", details: ["Temaki", "Crevettes"] },
    { id: "crunchy-saumon", name: "Crunchy Saumon", price: "24 DT", tier: 2, category: "Crunchy", categoryId: "crunchy", image: "assets/belt/crunchy.jpg",
      description: "Roll pané et doré. 24 DT les 6 pièces, 42 DT les 12.", details: ["6 pcs", "Saumon"] },
    { id: "uramaki-classic", name: "Uramaki Classic", price: "25 DT", tier: 3, category: "Uramaki", categoryId: "uramaki", image: "assets/belt/uramaki.jpg",
      description: "Le roll inversé, riz à l'extérieur.", details: ["Uramaki"] },
    { id: "fried-california-saumon", name: "Fried California Saumon", price: "27 DT", tier: 3, category: "Fried California", categoryId: "fried-california", image: "assets/belt/fried-california.jpg",
      description: "Version cheddar. En XL (dose + sauce fromage) : 32 DT.", details: ["Cheddar", "Saumon"] },
    { id: "ramen-poulet", name: "Ramen Poulet", price: "32 DT", tier: 3, category: "Ramen", categoryId: "ramen", image: "assets/belt/ramen.jpg",
      description: "Bol de nouilles en bouillon.", details: ["Plat principal", "Poulet"] },
    { id: "chirachi-saumon", name: "Chirachi Saumon", price: "35 DT", tier: 4, category: "Chirashi", categoryId: "chirashi", image: "assets/belt/chirashi.jpg",
      description: "Bol de riz vinaigré garni de saumon.", details: ["Bol", "Saumon"] },
    { id: "fried-rice-crevettes", name: "Fried Rice Crevettes", price: "38 DT", tier: 4, category: "Fried Rice", categoryId: "fried-rice", image: "assets/belt/fried-rice.jpg",
      description: "Riz sauté aux crevettes.", details: ["Plat principal", "Crevettes"] },
    { id: "philadelphia-roll", name: "Philadelphia", price: "40 DT", tier: 4, category: "Special Rolls", categoryId: "special-rolls", image: "assets/belt/philadelphia.jpg",
      description: "L'un des Special Rolls de la maison.", details: ["Special Roll"] },
    { id: "red-dragon", name: "Red Dragon Roll", price: "44 DT", tier: 4, category: "Special Rolls", categoryId: "special-rolls", image: "assets/belt/dragon.jpg",
      description: "Crevette, saumon, avocat.", details: ["Special Roll", "Crevette", "Saumon", "Avocat"] },
    { id: "tokyo-premium", name: "Tokyo Premium", price: "120 DT", tier: 5, category: "Sushi Feast", categoryId: "plateaux", image: "assets/belt/feast-5.jpg",
      description: "4 Nigiri, 3 Sashimi, 6 Hosomaki, 8 Uramaki, 6 Crunchy, 4 Dragon Rolls, 6 Fried California.", details: ["37 pièces", "À partager"] }
  ],
  beltLegend: { 1: "< 15 DT", 2: "15 – 24", 3: "25 – 34", 4: "35 – 49", 5: "50 DT +" },

  /* Spécialités mises en avant (familles réelles de la carte) */
  specials: [
    { name: "Salmon Roll", tag: "Signature", jp: "鮭", img: "assets/ig/ig-07.jpg", price: "dès 35",
      desc: "Avocat, crevettes, double saumon ou tataki : le saumon enveloppe le roll, coiffé d'œufs de saumon.", alt: "Salmon rolls coiffés d'œufs de saumon" },
    { name: "Ramen", tag: "Plat principal", jp: "拉麺", img: "assets/ig/ig-04.jpg", price: "dès 30",
      desc: "Bouillon fumant servi en marmite, en version vegan, poulet, crevettes ou saumon.", alt: "Ramen en marmite de fonte, œuf mollet et shiitake" },
    { name: "Special Rolls", tag: "Créations", jp: "龍", img: "assets/menu/dragon.jpg", price: "dès 38",
      desc: "Red Dragon, Black Dragon, Rainbow, Redfin Salmon, Philadelphia, Ebi Blossom.", alt: "Dragon roll garni d'avocat" },
    { name: "Crunchy", tag: "Croustillant", jp: "衣", img: "assets/ig/ig-08.jpg", price: "dès 21",
      desc: "Rolls panés et dorés, en 6 ou 12 pièces : poulet, saumon, saumon fumé, crevettes ou viande.", alt: "Makis crunchy panés et nigiri saumon" },
    { name: "Chirashi", tag: "Bol", jp: "散", img: "assets/menu/chirashi.jpg", price: "dès 29",
      desc: "Un bol de riz vinaigré garni : poulet, saumon, crevettes, ou « All » pour tout goûter.", alt: "Bol chirashi garni de poisson cru et légumes" },
    { name: "Sushi Feast", tag: "À partager", jp: "宴", img: "assets/ig/ig-02.jpg", price: "dès 33",
      desc: "Dix plateaux, de 12 à 83 pièces, pour les tables qui aiment partager.", alt: "Grands plateaux de sushi, makis et sashimi" }
  ],

  /* Galerie — photos publiées sur Instagram @sushipo.resto */
  gallery: [
    { src: "assets/ig/ig-02.jpg", alt: "Deux ardoises de sushi, makis panés et sashimi, avec thé vert" },
    { src: "assets/ig/ig-04.jpg", alt: "Ramen poulet en marmite, œuf mollet et shiitake" },
    { src: "assets/ig/ig-06.jpg", alt: "Assiette de nigiri, rose de saumon et uramaki" },
    { src: "assets/ig/ig-11.jpg", alt: "Roses de saumon aux œufs de saumon" },
    { src: "assets/ig/ig-05.jpg", alt: "Assortiment sushi et sauces sur plateau vert" },
    { src: "assets/ig/ig-01.jpg", alt: "Temaki aux œufs de saumon et au tartare de saumon" },
    { src: "assets/ig/ig-03.jpg", alt: "Futomaki saumon concombre, wasabi et gingembre" },
    { src: "assets/ig/ig-10.jpg", alt: "Table : ramen, yakitori sur riz et nigiri" },
    { src: "assets/ig/ig-07.jpg", alt: "Salmon rolls alignés sur marbre noir" }
  ]
};
