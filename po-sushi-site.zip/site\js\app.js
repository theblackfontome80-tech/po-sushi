/* =========================================================
   PO SUSHI — Interactions & rendu des composants
   Composants : SpecialCard, DishCard, DishRow, PlatterCard,
   CategoryBlock, FilterChip, GalleryTile, Lightbox
   ========================================================= */
(() => {
  "use strict";
  const D = window.PO_DATA;
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const esc = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmtPrice = p => {
    if (p == null || p === "") return "";
    const n = Number(p);
    const v = Number.isFinite(n) ? (Number.isInteger(n) ? String(n) : n.toFixed(3).replace(".", ",")) : esc(p);
    return `${v}<small>DT</small>`;
  };
  const Price = (d) => d.prices
    ? `<span class="dish-price multi">${d.prices.map(([l, p]) => `<span><em>${esc(l)}</em>${fmtPrice(p)}</span>`).join("")}</span>`
    : `<span class="dish-price">${fmtPrice(d.price)}</span>`;

  /* ---------- Composants ---------- */
  const Media = (img, alt, jp, label) => img
    ? `<img src="${img}" alt="${esc(alt)}" loading="lazy" decoding="async" width="518" height="640">`
    : `<div class="ph" aria-hidden="true"><span>${esc(jp || "寿")}</span><em>${esc(label || "PO SUSHI")}</em></div>`;

  const SpecialCard = (s) => `
    <article class="spec reveal">
      <img src="${s.img}" alt="${esc(s.alt || s.name)}" loading="lazy" decoding="async" width="518" height="640">
      ${s.price ? `<span class="spec-price">${fmtPrice(s.price).replace("<small>", " <small>")}</span>` : ""}
      ${s.jp ? `<span class="spec-kanji" aria-hidden="true">${esc(s.jp)}</span>` : ""}
      <div class="spec-body">
        <span class="spec-tag">${esc(s.tag)}</span>
        <h3>${esc(s.name)}</h3>
        <p>${esc(s.desc)}</p>
      </div>
    </article>`;

  const DishRow = (d) => `
    <div class="row">
      <h4>${esc(d.name)}</h4>${Price(d)}
      ${d.desc || d.pcs ? `<p>${esc([d.desc, d.pcs].filter(Boolean).join(" · "))}</p>` : ""}
    </div>`;

  // Bloc catégorie : visuel éditorial + liste des plats
  const CategoryBlock = (c, i) => `
    <section class="cat reveal${i % 2 ? " is-flip" : ""}" id="cat-${c.id}" data-cat="${c.id}" aria-labelledby="h-${c.id}">
      <div class="cat-visual">${Media(c.img, `${c.name} — PO SUSHI`, c.jp, c.name)}
        <span class="cat-visual-jp" aria-hidden="true">${esc(c.jp)}</span></div>
      <div class="cat-content">
        <header class="cat-head">
          <div><h3 id="h-${c.id}">${esc(c.name)}</h3>${c.note ? `<p>${esc(c.note)}</p>` : ""}</div>
          <span class="cat-count">${String(c.items.length).padStart(2, "0")}</span>
        </header>
        <div class="dish-list">${c.items.map(DishRow).join("")}</div>
      </div>
    </section>`;

  const PlatterCard = (p) => `
    <article class="platter reveal">
      <div class="platter-media">
        <img src="${p.img}" alt="${esc(p.name)} — plateau à partager" loading="lazy" decoding="async" width="518" height="640">
        ${p.pieces ? `<span class="platter-pcs"><span><b>${esc(p.pieces)}</b><small>pièces</small></span></span>` : ""}
      </div>
      <div class="platter-body">
        <h4>${esc(p.name)}</h4>
        ${p.items && p.items.length ? `<ul>${p.items.map(i => `<li>${esc(i)}</li>`).join("")}</ul>` : ""}
        ${p.desc ? `<p style="margin:0;color:var(--ink-60);font-size:14px">${esc(p.desc)}</p>` : ""}
        <div class="platter-foot"><span class="dish-price">${fmtPrice(p.price)}</span>
          <a class="link-arrow" href="tel:+21650848962"><span>Commander</span> →</a></div>
      </div>
    </article>`;

  const FilterChip = (id, label, count, pressed) =>
    `<button class="chip" type="button" data-filter="${id}" aria-pressed="${pressed}">${esc(label)}${count != null ? ` <small>${count}</small>` : ""}</button>`;

  const GalleryTile = (g, i) => `
    <button class="g reveal" type="button" data-index="${i}" aria-label="Agrandir : ${esc(g.alt)}">
      <img src="${g.src}" alt="${esc(g.alt)}" loading="lazy" decoding="async" width="518" height="640">
    </button>`;

  /* ---------- Rendu ---------- */
  $("#specials-grid").innerHTML = D.specials.map(SpecialCard).join("");

  const cats = D.categories;
  const total = cats.reduce((n, c) => n + c.items.length, 0);
  $("#filters").innerHTML = FilterChip("all", "Tout", total, true) +
    cats.map(c => FilterChip(c.id, c.name, c.items.length, false)).join("") +
    (D.platters.length ? FilterChip("plateaux", "Sushi Feast", D.platters.length, false) : "");
  $("#menu-body").innerHTML = cats.map(CategoryBlock).join("");
  $("#platter-grid").innerHTML = D.platters.map(PlatterCard).join("");

  $("#gallery").innerHTML = D.gallery.map(GalleryTile).join("");

  /* ---------- Filtres ---------- */
  const filters = $("#filters");
  const platters = $("#plateaux");
  filters.addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    const f = chip.dataset.filter;
    $$(".chip", filters).forEach(c => c.setAttribute("aria-pressed", String(c === chip)));
    chip.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
    $$(".cat").forEach(c => { c.hidden = !(f === "all" || c.dataset.cat === f); });
    platters.hidden = !(f === "all" || f === "plateaux");
    // révéler immédiatement les éléments déjà filtrés
    $$("#menu .reveal:not(.is-in)").forEach(el => el.classList.add("is-in"));
    const target = f === "all" ? $("#menu-body") : (f === "plateaux" ? platters : $(`#cat-${f}`));
    const y = target.getBoundingClientRect().top + window.scrollY - (parseInt(getComputedStyle(document.documentElement).getPropertyValue("--nav-h")) + 80);
    if (Math.abs(window.scrollY - y) > 40) window.scrollTo({ top: y, behavior: "smooth" });
  });

  /* ---------- Tapis kaiten ---------- */
  const kaitenEl = $("#kaiten");
  if (kaitenEl && window.SushiConveyor && D.belt && D.belt.length) {
    new window.SushiConveyor(kaitenEl, {
      items: D.belt,
      legend: D.beltLegend,
      eyebrow: "Le tapis · 回転寿司",
      heading: "La carte défile,<br>servez-vous des <em>yeux</em>.",
      caption: "Survolez pour arrêter le tapis, faites-le glisser pour le lancer, touchez une assiette pour la découvrir.",
      ariaLabel: "Tapis roulant des plats PO SUSHI",
      autoplay: true,
      orderHref: "tel:+21650848962",
      labels: { order: "Commander", close: "Fermer", see: "Voir dans la carte" },
      action: `<a href="#menu-body" class="link-arrow k-action"><span>Toute la carte ci-dessous</span> ↓</a>`,
      onSeeCategory: (id) => {
        const chip = filters.querySelector(`[data-filter="${id}"]`);
        if (chip) chip.click();
      }
    });
  }

  /* ---------- Navigation ---------- */
  const nav = $("#nav");
  const toTop = $("#to-top");
  const orderBar = $("#order-bar");
  const ring = $(".to-top .ring circle");
  let lastY = 0, ticking = false;
  const onScroll = () => {
    const y = window.scrollY;
    const h = document.documentElement.scrollHeight - innerHeight;
    nav.classList.toggle("is-solid", y > 40);
    const hide = y > 600 && y > lastY && !document.body.classList.contains("menu-open");
    nav.classList.toggle("is-hidden", hide);
    document.body.classList.toggle("nav-hidden", hide);
    toTop.classList.toggle("is-visible", y > innerHeight * .8);
    orderBar.classList.toggle("is-visible", y > innerHeight * .6);
    ring.style.setProperty("--p", String(169.6 * (1 - Math.min(1, y / h))));
    lastY = y; ticking = false;
  };
  addEventListener("scroll", () => { if (!ticking) { requestAnimationFrame(onScroll); ticking = true; } }, { passive: true });
  onScroll();
  [toTop, $("#bar-top")].forEach(b => b && b.addEventListener("click", () => scrollTo({ top: 0, behavior: "smooth" })));

  // lien actif
  const links = $$(".nav-links a");
  const spy = new IntersectionObserver((entries) => {
    entries.forEach(en => {
      if (en.isIntersecting) links.forEach(a => a.classList.toggle("is-active", a.getAttribute("href") === `#${en.target.id}`));
    });
  }, { rootMargin: "-45% 0px -50% 0px" });
  ["specialites", "menu", "univers", "galerie", "visite"].forEach(id => { const el = document.getElementById(id); if (el) spy.observe(el); });

  // menu mobile
  const burger = $("#burger");
  const mm = $("#mobile-menu");
  const setMenu = (open) => {
    document.body.classList.toggle("menu-open", open);
    burger.setAttribute("aria-expanded", String(open));
    burger.setAttribute("aria-label", open ? "Fermer le menu" : "Ouvrir le menu");
    mm.setAttribute("aria-hidden", String(!open));
  };
  burger.addEventListener("click", () => setMenu(!document.body.classList.contains("menu-open")));
  $$("a", mm).forEach(a => a.addEventListener("click", () => setMenu(false)));
  addEventListener("keydown", e => { if (e.key === "Escape") { setMenu(false); closeLb(); } });

  /* ---------- Révélations ---------- */
  const io = new IntersectionObserver((entries) => {
    entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add("is-in"); io.unobserve(en.target); } });
  }, { rootMargin: "0px 0px -8% 0px", threshold: .08 });
  $$(".reveal, .reveal-img").forEach(el => io.observe(el));

  /* ---------- Lightbox ---------- */
  const lb = $("#lightbox"), lbImg = $("#lb-img"), lbCount = $("#lb-count");
  let idx = 0, lastFocus = null;
  const show = (i) => {
    idx = (i + D.gallery.length) % D.gallery.length;
    lbImg.src = D.gallery[idx].src; lbImg.alt = D.gallery[idx].alt;
    lbCount.textContent = `${String(idx + 1).padStart(2, "0")} / ${String(D.gallery.length).padStart(2, "0")}`;
  };
  const openLb = (i) => { lastFocus = document.activeElement; show(i); lb.classList.add("is-open"); lb.setAttribute("aria-hidden", "false"); document.body.style.overflow = "hidden"; $("#lb-close").focus(); };
  function closeLb() { if (!lb.classList.contains("is-open")) return; lb.classList.remove("is-open"); lb.setAttribute("aria-hidden", "true"); document.body.style.overflow = ""; lastFocus && lastFocus.focus(); }
  $("#gallery").addEventListener("click", e => { const t = e.target.closest(".g"); if (t) openLb(+t.dataset.index); });
  $("#lb-close").addEventListener("click", closeLb);
  $("#lb-prev").addEventListener("click", () => show(idx - 1));
  $("#lb-next").addEventListener("click", () => show(idx + 1));
  lb.addEventListener("click", e => { if (e.target === lb) closeLb(); });
  addEventListener("keydown", e => { if (!lb.classList.contains("is-open")) return; if (e.key === "ArrowRight") show(idx + 1); if (e.key === "ArrowLeft") show(idx - 1); });
  let tx = 0;
  lb.addEventListener("touchstart", e => { tx = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener("touchend", e => { const dx = e.changedTouches[0].clientX - tx; if (Math.abs(dx) > 50) show(idx + (dx < 0 ? 1 : -1)); });

  /* ---------- Statut ouvert / fermé (heure de Tunis) ---------- */
  const status = $("#status");
  if (status) {
    const now = new Date(new Date().toLocaleString("en-US", { timeZone: "Africa/Tunis" }));
    const m = now.getHours() * 60 + now.getMinutes();
    const open = m >= 11 * 60 + 30;
    status.classList.toggle("open", open);
    status.lastElementChild.textContent = open ? "Ouvert maintenant" : "Ouvre à 11h30";
  }
  $("#year").textContent = new Date().getFullYear();
})();
