/* =========================================================
   PO SUSHI — Tapis kaiten (composant SushiConveyorMenu)
   Portage en JavaScript natif du composant React « sushi-conveyor-menu » :
   même géométrie (boucle en stade, perspective), même physique (croisière,
   ressorts de levée, glisser / lancer), mêmes contrôles et dialogue animé.
   Usage : new SushiConveyor(element, { items, legend, ... })
   ========================================================= */
(() => {
  "use strict";

  const SPACING = 1.35, CURVE = 0.95, BAND = 1.22, TILT = 0.8, SLAT = 0.34;
  const LIFT_Y = -6, LIFT_SCALE = 0.08, BACK_SHADE = 0.15, CHIP_ROOM = 34, WIDE = 1024, HOLD = 1400;
  const RUN = 0, SEEK = 1, DRAG = 2;
  const SVGNS = "http://www.w3.org/2000/svg";

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const tierOf = (t) => clamp(Math.round(t || 1), 1, 5);
  const pad = (v) => String(v).padStart(2, "0");
  const esc = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  /* ---------- Géométrie ---------- */
  function along(g, u) {
    const { s, r } = g;
    let t = ((u % g.l) + g.l) % g.l;
    if (t < s) return { x: s / 2 - t, z: r, nx: 0, nz: 1, tx: -1, tz: 0 };
    t -= s;
    const arc = Math.PI * r;
    if (t < arc) { const f = t / r, sin = Math.sin(f), cos = Math.cos(f); return { x: -s / 2 - r * sin, z: r * cos, nx: -sin, nz: cos, tx: -cos, tz: -sin }; }
    t -= arc;
    if (t < s) return { x: -s / 2 + t, z: -r, nx: 0, nz: -1, tx: 1, tz: 0 };
    t -= s;
    const f = Math.min(Math.PI, t / r), sin = Math.sin(f), cos = Math.cos(f);
    return { x: s / 2 + r * sin, z: -r * cos, nx: sin, nz: -cos, tx: cos, tz: sin };
  }
  function project(g, x, z) { const k = g.a + g.b * z; return { x: g.cx + x * k, y: g.ym + TILT * (g.a * z + (g.b * z * z) / 2), k }; }
  function makeGeo(width, n, d, kb) {
    const l = Math.max(1, n) * SPACING * d;
    const r = Math.min(CURVE * d, l / (2 * Math.PI));
    const s = Math.max(0, (l - 2 * Math.PI * r) / 2);
    const g = { width, height: 0, d, r, s, l, pitch: l / Math.max(1, n), n: Math.max(1, n), kb, cx: width / 2, ym: 0, a: (1 + kb) / 2, b: (1 - kb) / (2 * r), band: BAND * d, slats: Math.max(10, Math.round(l / (SLAT * d))), side: Math.max(3, d * 0.07), edgeTop: 0 };
    let top = Infinity, bottom = -Infinity, edge = Infinity;
    for (let j = 0; j < 120; j++) {
      const p = along(g, (j / 120) * l);
      const rim = project(g, p.x + (p.nx * g.band) / 2, p.z + (p.nz * g.band) / 2);
      const plate = project(g, p.x, p.z);
      const half = (plate.k * d * TILT) / 2;
      edge = Math.min(edge, rim.y);
      top = Math.min(top, rim.y, plate.y + (LIFT_Y / 100) * half * 2 - half * (1 + LIFT_SCALE) - CHIP_ROOM);
      bottom = Math.max(bottom, rim.y + g.side + d * 0.06, plate.y + half + d * 0.08);
    }
    g.ym = Math.ceil(-top) + 2;
    g.height = Math.ceil(bottom - top) + 4;
    g.edgeTop = edge + g.ym;
    return g;
  }
  function halfSpan(g) {
    let span = 0;
    for (let j = 0; j < 120; j++) {
      const p = along(g, (j / 120) * g.l);
      const rim = project(g, p.x + (p.nx * g.band) / 2, p.z + (p.nz * g.band) / 2);
      const plate = project(g, p.x, p.z);
      span = Math.max(span, Math.abs(rim.x - g.cx) + 3, Math.abs(plate.x - g.cx) + (plate.k * g.d * (1 + LIFT_SCALE)) / 2);
    }
    return span;
  }
  function edgePath(g, off) {
    let d = "";
    for (let j = 0; j < 168; j++) { const p = along(g, (j / 168) * g.l); const q = project(g, p.x + p.nx * off, p.z + p.nz * off); d += `${j ? "L" : "M"}${q.x.toFixed(1)} ${q.y.toFixed(1)}`; }
    return d + "Z";
  }
  function slatPath(g, offset, shift) {
    const half = g.band * 0.46, pitch = g.l / g.slats, bulge = pitch * 0.2;
    let d = "";
    for (let j = 0; j < g.slats; j++) {
      const p = along(g, offset + shift + j * pitch);
      const a = project(g, p.x - p.nx * half, p.z - p.nz * half);
      const b = project(g, p.x + p.nx * half, p.z + p.nz * half);
      const m = project(g, p.x + p.tx * bulge, p.z + p.tz * bulge);
      d += `M${a.x.toFixed(1)} ${a.y.toFixed(1)}Q${(2 * m.x - (a.x + b.x) / 2).toFixed(1)} ${(2 * m.y - (a.y + b.y) / 2).toFixed(1)} ${b.x.toFixed(1)} ${b.y.toFixed(1)}`;
    }
    return d;
  }
  function pose(g, offset, i) { const p = along(g, offset - i * g.pitch); const q = project(g, p.x, p.z); return { x: q.x, y: q.y, k: q.k, depth: (p.z + g.r) / (2 * g.r) }; }
  const centerOf = (g, offset) => ((Math.round((offset - g.s / 2) / g.pitch) % g.n) + g.n) % g.n;
  const svg = (tag, attrs = {}) => { const el = document.createElementNS(SVGNS, tag); for (const k in attrs) el.setAttribute(k, attrs[k]); return el; };

  /* ---------- Composant ---------- */
  class SushiConveyor {
    constructor(root, opts) {
      this.root = root;
      this.o = Object.assign({ speed: 26, autoplay: true, interval: 3000, labels: {} }, opts);
      this.L = Object.assign({ order: "Commander", close: "Fermer", previous: "Assiette précédente", next: "Assiette suivante", pause: "Mettre le tapis en pause", see: "Voir dans la carte" }, this.o.labels);
      this.items = this.o.items;
      this.n = this.items.length;
      this.uid = "k" + Math.random().toString(36).slice(2, 8);
      this.reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
      this.active = null; this.paused = false; this.openIndex = null; this.playing = !!this.o.autoplay;
      this.center = 0; this.autoActive = null; this.autoLast = null; this.autoTimer = 0; this.lifted = null;
      this.s = { offset: 0, v: 0, mode: RUN, target: 0, lift: [], vlift: [], z: [], lane: [], raf: 0, last: 0, visible: false, init: false, touched: false, l: 0, center: -1, published: "", px: 0, py: 0, inside: false, lock: false, lockX: 0, lockY: 0 };
      this.p = { id: -1, index: -1, x: 0, y: 0, moved: false, start: 0, lane: 1, lastX: 0, lastT: 0, v: 0 };
      this.pendingOpen = -1;
      this.geo = null; this.size = { section: 0, stage: 0 };
      this.tick = this.tick.bind(this);
      this.build();
      this.bind();
    }

    /* ----- DOM ----- */
    build() {
      const o = this.o;
      const tiers = [];
      for (let t = 1; t <= 5; t++) { const label = o.legend ? o.legend[t] : (this.items.find(i => tierOf(i.tier) === t) || {}).price; if (label) tiers.push({ t, label }); }
      this.root.classList.add("kaiten");
      this.root.innerHTML = `
        <div class="k-grid">
          <div class="k-side">
            ${o.eyebrow ? `<span class="eyebrow">${esc(o.eyebrow)}</span>` : ""}
            ${o.heading ? `<h3 class="k-heading">${o.heading}</h3>` : ""}
            ${tiers.length ? `<ul class="k-legend" aria-hidden="true">${tiers.map(e => `<li><i class="t${e.t}"></i>${esc(e.label)}</li>`).join("")}</ul>` : ""}
            <div class="k-caption" id="${this.uid}-caption" aria-live="polite"></div>
            ${o.action || ""}
          </div>
          <div class="k-main">
            <div class="k-stage" role="group" aria-label="${esc(o.ariaLabel || "Tapis roulant de sushis")}" aria-roledescription="tapis roulant">
              <div class="k-counter" aria-hidden="true"></div>
              <div class="k-belt" aria-hidden="true"></div>
            </div>
            <div class="k-controls">
              <button type="button" class="k-ctl" data-c="prev" aria-label="${esc(this.L.previous)}"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3.5 5.5 8l4.5 4.5"/></svg></button>
              <button type="button" class="k-ctl" data-c="pause" aria-label="${esc(this.L.pause)}" aria-pressed="false"></button>
              <button type="button" class="k-ctl" data-c="next" aria-label="${esc(this.L.next)}"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3.5 10.5 8 6 12.5"/></svg></button>
            </div>
          </div>
        </div>`;
      this.stage = this.root.querySelector(".k-stage");
      this.beltEl = this.root.querySelector(".k-belt");
      this.counter = this.root.querySelector(".k-counter");
      this.caption = this.root.querySelector(".k-caption");
      this.pauseBtn = this.root.querySelector('[data-c="pause"]');
      this.renderPause();

      // SVG du tapis
      const sv = svg("svg", { class: "k-svg", focusable: "false" });
      const defs = svg("defs");
      const f = svg("filter", { id: `${this.uid}-soft`, x: "-10%", y: "-30%", width: "120%", height: "160%" });
      this.blur = svg("feGaussianBlur", { stdDeviation: "6" }); f.append(this.blur);
      const lg = svg("linearGradient", { id: `${this.uid}-isl`, x1: "0", x2: "0", y1: "0", y2: "1" });
      lg.append(svg("stop", { offset: "0", style: "stop-color:var(--k-island)" }), svg("stop", { offset: "1", style: "stop-color:var(--k-island-low)" }));
      defs.append(f, lg); sv.append(defs);
      this.pth = {
        shadow: svg("path", { fill: "black", opacity: ".22", filter: `url(#${this.uid}-soft)` }),
        side: svg("path", { "fill-rule": "evenodd", style: "fill:var(--k-belt-side)" }),
        belt: svg("path", { "fill-rule": "evenodd", style: "fill:var(--k-belt)" }),
        seam: svg("path", { fill: "none", stroke: "black", "stroke-opacity": ".42", "stroke-linecap": "round" }),
        glint: svg("path", { fill: "none", stroke: "white", "stroke-opacity": ".14", "stroke-linecap": "round" }),
        outer: svg("path", { fill: "none", style: "stroke:var(--k-rail)" }),
        outerHi: svg("path", { fill: "none", stroke: "white", "stroke-opacity": ".55", transform: "translate(0 -0.8)" }),
        inner: svg("path", { fill: "none", style: "stroke:var(--k-rail)" }),
        innerHi: svg("path", { fill: "none", stroke: "white", "stroke-opacity": ".4", transform: "translate(0 -0.7)" }),
        wall: svg("path", { style: "fill:var(--k-island-wall)" }),
        island: svg("path", { style: `fill:url(#${this.uid}-isl)` }),
        islandHi: svg("path", { fill: "none", stroke: "white", "stroke-opacity": ".55" })
      };
      Object.values(this.pth).forEach(p => sv.append(p));
      this.svgEl = sv; this.beltEl.append(sv);

      // Assiettes
      this.plates = []; this.lifts = []; this.shades = []; this.shadows = []; this.anchors = []; this.chips = [];
      this.items.forEach((it, i) => {
        const b = document.createElement("button");
        b.type = "button"; b.className = "k-plate"; b.dataset.dish = i; b.tabIndex = -1;
        b.setAttribute("aria-label", `${it.name}, ${it.price}`);
        b.setAttribute("aria-describedby", `${this.uid}-caption`);
        b.setAttribute("aria-haspopup", "dialog");
        b.innerHTML = `
          <span class="k-shadow-wrap" aria-hidden="true"><span class="k-shadow"></span></span>
          <span class="k-lift">
            <span class="k-dish t${tierOf(it.tier)}" aria-hidden="true"><img src="${it.image}" alt="" draggable="false" decoding="async"></span>
            <span class="k-shade" aria-hidden="true"></span>
            <span class="k-anchor" aria-hidden="true"><span class="k-chip"><i class="t${tierOf(it.tier)}"></i>${esc(it.name)}<em>${esc(it.price)}</em></span></span>
          </span>`;
        b.querySelector("img").addEventListener("error", e => e.target.remove());
        this.stage.append(b);
        this.plates.push(b);
        this.lifts.push(b.querySelector(".k-lift"));
        this.shades.push(b.querySelector(".k-shade"));
        this.shadows.push(b.querySelector(".k-shadow"));
        this.anchors.push(b.querySelector(".k-anchor"));
        this.chips.push(b.querySelector(".k-chip"));
      });
      this.renderCaption();
    }

    renderPause() {
      this.pauseBtn.setAttribute("aria-pressed", String(this.paused));
      this.pauseBtn.innerHTML = this.paused
        ? '<svg viewBox="0 0 16 16" fill="currentColor"><path d="M5 3.4v9.2a.6.6 0 0 0 .9.5l7.4-4.6a.6.6 0 0 0 0-1L5.9 2.9a.6.6 0 0 0-.9.5Z"/></svg>'
        : '<svg viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="3" width="2.6" height="10" rx=".8"/><rect x="9.4" y="3" width="2.6" height="10" rx=".8"/></svg>';
    }
    renderCaption() {
      const it = this.active === null ? null : this.items[this.active];
      this.caption.classList.toggle("is-on", !!it);
      this.caption.innerHTML = it
        ? `<p><b>${esc(it.name)}</b> <span>· ${esc(it.price)}</span></p>${it.description ? `<p class="k-desc">${esc(it.description)}</p>` : ""}`
        : `<p>${esc(this.o.caption || "")}</p>`;
    }
    renderActive() {
      this.plates.forEach((b, i) => {
        const on = this.active === i;
        b.toggleAttribute("data-active", on);
        if (on) b.setAttribute("aria-current", "true"); else b.removeAttribute("aria-current");
        this.chips[i].classList.toggle("is-on", on && this.lifted !== i);
      });
      this.renderRoving();
      this.renderCaption();
    }
    renderRoving() {
      const r = this.active ?? this.center;
      this.plates.forEach((b, i) => { b.tabIndex = i === r ? 0 : -1; });
    }

    /* ----- Mise en page ----- */
    measure() {
      const next = { section: Math.round(this.root.clientWidth), stage: Math.round(this.stage.clientWidth) };
      const wide = next.section >= WIDE;
      this.root.dataset.layout = wide ? "wide" : "stack";
      next.stage = Math.round(this.stage.clientWidth);
      if (next.section === this.size.section && next.stage === this.size.stage) return;
      this.size = next;
      this.layout();
    }
    layout() {
      const { section, stage } = this.size;
      if (!stage || !this.n) return;
      const wide = section >= WIDE, narrow = section > 0 && section < 480;
      const kb = narrow ? 0.6 : 0.68;
      const span = halfSpan(makeGeo(1000, this.n, 100, kb)) / 100;
      const cap = wide ? 150 : clamp(section * 0.143, 96, 150);
      const fit = (stage - 8) / (2 * span);
      const g = makeGeo(stage, this.n, Math.round(clamp(fit, Math.min(96, cap), cap)), kb);
      this.geo = g;
      this.root.classList.toggle("is-narrow", narrow);

      this.stage.style.height = g.height + "px";
      const top = Math.max(0, g.edgeTop - g.d * 0.34);
      Object.assign(this.counter.style, { top: top + "px", height: Math.max(0, g.ym - top) + "px" });
      const sv = this.svgEl;
      sv.setAttribute("width", g.width); sv.setAttribute("height", g.height); sv.setAttribute("viewBox", `0 0 ${g.width} ${g.height}`);
      const outer = edgePath(g, g.band / 2), inner = edgePath(g, -g.band / 2), island = edgePath(g, -g.band / 2 - g.d * 0.035);
      const P = this.pth;
      this.blur.setAttribute("stdDeviation", (g.d * 0.06).toFixed(1));
      P.shadow.setAttribute("d", outer); P.shadow.setAttribute("transform", `translate(0 ${(g.side + g.d * 0.07).toFixed(1)})`);
      P.side.setAttribute("d", outer + inner); P.side.setAttribute("transform", `translate(0 ${g.side.toFixed(1)})`);
      P.belt.setAttribute("d", outer + inner);
      P.seam.setAttribute("stroke-width", Math.max(1, g.d * 0.013));
      P.glint.setAttribute("stroke-width", Math.max(0.8, g.d * 0.009));
      P.outer.setAttribute("d", outer); P.outer.setAttribute("stroke-width", Math.max(2, g.d * 0.026));
      P.outerHi.setAttribute("d", outer); P.outerHi.setAttribute("stroke-width", Math.max(0.8, g.d * 0.008));
      P.inner.setAttribute("d", inner); P.inner.setAttribute("stroke-width", Math.max(1.6, g.d * 0.02));
      P.innerHi.setAttribute("d", inner); P.innerHi.setAttribute("stroke-width", Math.max(0.8, g.d * 0.008));
      P.wall.setAttribute("d", island);
      P.island.setAttribute("d", island); P.island.setAttribute("transform", `translate(0 ${(-g.side * 0.6).toFixed(1)})`);
      P.islandHi.setAttribute("d", island); P.islandHi.setAttribute("transform", `translate(0 ${(-g.side * 0.6 - 0.6).toFixed(1)})`); P.islandHi.setAttribute("stroke-width", Math.max(0.8, g.d * 0.008));
      this.plates.forEach(b => { b.style.width = g.d + "px"; b.style.height = g.d * TILT + "px"; });
      this.shadows.forEach(sh => { sh.style.filter = `blur(${Math.max(2, g.d * 0.045).toFixed(1)}px)`; });

      const s = this.s;
      if (!s.init) {
        s.init = true;
        s.offset = g.s / 2 - Math.min(this.o.speed * 1.62, g.pitch * 0.45);
        s.v = this.reduced || this.paused ? 0 : this.o.speed;
      } else if (s.l > 0 && s.l !== g.l) { const f = g.l / s.l; s.offset *= f; s.target *= f; }
      if (this.reduced) { s.v = 0; if (s.mode !== DRAG) s.mode = RUN; if (!s.touched) s.offset = g.s / 2; }
      s.l = g.l; s.z = []; s.lane = [];
      this.paintAll();
      this.kick();
    }

    /* ----- Peinture ----- */
    paintPlate(i) {
      const g = this.geo, s = this.s, b = this.plates[i];
      if (!g || !b) return;
      const q = pose(g, s.offset, i), e = s.lift[i] ?? 0;
      b.style.transform = `translate3d(${(q.x - g.d / 2).toFixed(2)}px,${(q.y - (g.d * TILT) / 2).toFixed(2)}px,0) scale(${q.k.toFixed(4)})`;
      const z = i === this.active ? 2000 : 100 + Math.round(q.y);
      if (s.z[i] !== z) { s.z[i] = z; b.style.zIndex = z; }
      const lane = q.depth >= 0.5 ? "front" : "back";
      if (s.lane[i] !== lane) { s.lane[i] = lane; b.dataset.lane = lane; }
      this.lifts[i].style.transform = `translateY(${(LIFT_Y * e).toFixed(3)}%) scale(${(1 + LIFT_SCALE * e).toFixed(4)})`;
      this.shades[i].style.opacity = (BACK_SHADE * clamp(1 - q.depth, 0, 1) * (1 - 0.7 * clamp(e, 0, 1))).toFixed(3);
      this.shadows[i].style.transform = `translate3d(0,${(g.d * TILT * 0.05 * e).toFixed(2)}px,0) scale(${(1 + 0.14 * e).toFixed(3)})`;
      this.shadows[i].style.opacity = (1 - 0.5 * clamp(e, 0, 1)).toFixed(3);
      this.anchors[i].style.transform = `scale(${(1 / (q.k * (1 + LIFT_SCALE * e))).toFixed(4)})`;
    }
    paintBelt() {
      const g = this.geo, s = this.s;
      if (!g) return;
      this.pth.seam.setAttribute("d", slatPath(g, s.offset, 0));
      this.pth.glint.setAttribute("d", slatPath(g, s.offset, -Math.max(1.4, g.d * 0.024)));
      const c = centerOf(g, s.offset);
      if (c !== s.center) { s.center = c; this.center = c; if (this.active === null) this.renderRoving(); }
    }
    paintAll() { for (let i = 0; i < this.n; i++) this.paintPlate(i); this.paintBelt(); }

    hitTest(px, py) {
      const g = this.geo, s = this.s;
      if (!g) return null;
      let best = null, bestY = -Infinity;
      for (let i = 0; i < this.n; i++) {
        const q = pose(g, s.offset, i), e = clamp(s.lift[i] ?? 0, 0, 1.2);
        const grow = (1 + LIFT_SCALE * e) * (i === this.active ? 1.1 : 1);
        const rx = (g.d * q.k * grow) / 2, ry = (g.d * TILT * q.k * grow) / 2;
        const dx = (px - q.x) / rx, dy = (py - (q.y + (LIFT_Y / 100) * g.d * TILT * q.k * e)) / ry;
        if (dx * dx + dy * dy > 1) continue;
        if (i === this.active) return i;
        if (q.y > bestY) { best = i; bestY = q.y; }
      }
      return best;
    }

    /* ----- Boucle d'animation ----- */
    tick(now) {
      const s = this.s, g = this.geo;
      s.raf = 0;
      if (!g || !s.visible) { s.last = 0; return; }
      const dt = s.last ? clamp((now - s.last) / 1000, 0, 0.25) : 1 / 60;
      s.last = now;
      const steps = Math.max(1, Math.ceil(dt / 0.017)), h = dt / steps;
      const stopped = this.paused || this.active !== null || this.openIndex !== null;
      const cruise = this.reduced ? 0 : this.o.speed;
      for (let step = 0; step < steps; step++) {
        if (s.mode === SEEK) {
          const w = 5.6;
          s.v += (w * w * (s.target - s.offset) - 2 * w * s.v) * h;
          s.offset += s.v * h;
          if (Math.abs(s.target - s.offset) < 0.3 && Math.abs(s.v) < 4) { s.offset = s.target; s.v = 0; s.mode = RUN; }
        } else if (s.mode === RUN) {
          if (stopped) { s.v *= Math.exp(-7.2 * h); if (Math.abs(s.v) < 0.02) s.v = 0; }
          else {
            let e = s.v - cruise;
            if (Math.abs(e) > Math.max(6, cruise * 0.5)) e = Math.sign(e) * Math.max(0, Math.abs(e) * Math.exp(-2.4 * h) - 90 * h);
            else e *= Math.exp(-3.4 * h);
            s.v = cruise + (Math.abs(e) < 0.01 ? 0 : e);
          }
          s.offset += s.v * h;
        }
        for (let i = 0; i < this.n; i++) {
          const goal = i === this.active ? 1 : 0;
          if (this.reduced) { s.lift[i] = goal; s.vlift[i] = 0; continue; }
          const x = s.lift[i] ?? 0, vl = s.vlift[i] ?? 0;
          const v = vl + (330 * (goal - x) - 23 * vl) * h;
          s.lift[i] = x + v * h; s.vlift[i] = v;
        }
      }
      let busy = s.mode !== RUN || s.v !== 0 || (!stopped && cruise > 0);
      for (let i = 0; i < this.n; i++) {
        const goal = i === this.active ? 1 : 0;
        if (Math.abs(goal - (s.lift[i] ?? 0)) < 0.002 && Math.abs(s.vlift[i] ?? 0) < 0.02) { s.lift[i] = goal; s.vlift[i] = 0; }
        else busy = true;
      }
      if (s.inside && !s.lock && s.mode === RUN && this.openIndex === null && this.p.id < 0 && Math.abs(s.v) > 0.3) {
        const hit = this.hitTest(s.px, s.py);
        if (hit !== null && hit !== this.active) this.hover(hit);
      }
      this.paintAll();
      if (busy) s.raf = requestAnimationFrame(this.tick); else s.last = 0;
    }
    kick() { const s = this.s; if (s.raf || !s.visible) return; s.last = 0; s.raf = requestAnimationFrame(this.tick); }

    /* ----- État ----- */
    setActive(next) {
      if (this.active === next) return;
      this.active = next;
      this.renderActive();
      this.kick();
    }
    stop() {
      this.playing = false;
      clearTimeout(this.autoTimer);
      this.s.touched = true;
      if (this.s.mode === SEEK) this.s.mode = RUN;
      const a = this.autoActive;
      if (a !== null) { this.autoActive = null; if (this.active === a) this.setActive(null); }
    }
    seekTo(index) {
      const s = this.s, g = this.geo;
      if (!g) return;
      const base = g.s / 2 + index * g.pitch;
      s.target = base + Math.round((s.offset - base) / g.l) * g.l;
      if (this.reduced) { s.offset = s.target; s.v = 0; s.mode = RUN; this.paintAll(); return; }
      s.mode = SEEK; this.kick();
    }
    focusVisible() { return !!this.stage.querySelector(".k-plate:focus-visible"); }
    hover(hit) {
      const cur = this.active;
      if (hit === cur) { if (hit !== null && this.autoActive === hit) { this.autoActive = null; this.playing = false; clearTimeout(this.autoTimer); } return; }
      if (hit !== null) { this.stop(); this.setActive(hit); return; }
      if (cur !== null && cur !== this.autoActive && !this.focusVisible()) this.setActive(null);
    }
    go(index, focus) {
      if (!this.n) return;
      const next = ((index % this.n) + this.n) % this.n;
      this.stop();
      if (focus) this.plates[next].focus({ preventScroll: true });
      this.setActive(next);
      this.seekTo(next);
    }
    togglePause() {
      this.stop();
      this.paused = !this.paused;
      this.renderPause();
      if (!this.paused && this.active !== null && !this.focusVisible() && !this.s.inside) this.setActive(null);
      this.kick();
    }

    /* ----- Lecture automatique ----- */
    syncAuto() {
      clearTimeout(this.autoTimer);
      if (!this.playing || this.reduced || this.paused || this.openIndex !== null || !this.n || !this.geo || !this.s.visible) return;
      const show = () => {
        const g = this.geo; if (!g) return;
        const index = this.autoLast === null ? centerOf(g, this.s.offset + this.o.speed * 0.25) : (this.autoLast + 1) % this.n;
        this.autoLast = index; this.autoActive = index;
        this.setActive(index); this.seekTo(index);
        this.autoTimer = setTimeout(() => {
          if (this.autoActive === index) { this.autoActive = null; if (this.active === index) this.setActive(null); }
          this.autoTimer = setTimeout(show, Math.max(300, this.o.interval - HOLD));
        }, HOLD);
      };
      this.autoTimer = setTimeout(show, this.autoLast === null ? 1600 : Math.max(300, this.o.interval - HOLD));
    }

    /* ----- Événements ----- */
    local(e) { const b = this.stage.getBoundingClientRect(); return { x: e.clientX - b.left, y: e.clientY - b.top }; }
    bind() {
      const st = this.stage, s = this.s;
      new ResizeObserver(() => this.measure()).observe(this.root);
      this.measure();

      const io = new IntersectionObserver((en) => {
        const vis = en.some(x => x.isIntersecting) && !document.hidden;
        if (vis === s.visible) return;
        s.visible = vis;
        if (vis) { this.kick(); this.syncAuto(); } else { if (s.raf) cancelAnimationFrame(s.raf); s.raf = 0; s.last = 0; clearTimeout(this.autoTimer); }
      });
      io.observe(this.root);
      document.addEventListener("visibilitychange", () => { if (document.hidden) { s.visible = false; clearTimeout(this.autoTimer); } else { io.unobserve(this.root); io.observe(this.root); } });
      matchMedia("(prefers-reduced-motion: reduce)").addEventListener("change", (m) => { this.reduced = m.matches; this.layout(); this.syncAuto(); });

      this.root.querySelector('[data-c="prev"]').addEventListener("click", () => this.go((this.active ?? this.s.center) - 1, false));
      this.root.querySelector('[data-c="next"]').addEventListener("click", () => this.go((this.active ?? this.s.center) + 1, false));
      this.pauseBtn.addEventListener("click", () => this.togglePause());

      st.addEventListener("pointerdown", (e) => {
        const g = this.geo; if (e.button !== 0 || !g) return;
        const at = this.local(e), hit = this.hitTest(at.x, at.y);
        this.pendingOpen = -1;
        this.p = { id: e.pointerId, index: hit ?? -1, x: e.clientX, y: e.clientY, moved: false, start: s.offset, lane: at.y >= g.ym ? 1 : -1, lastX: e.clientX, lastT: e.timeStamp, v: 0 };
      });
      st.addEventListener("pointermove", (e) => {
        const p = this.p, g = this.geo; if (!g) return;
        const at = this.local(e);
        if (e.pointerType === "mouse") { s.px = at.x; s.py = at.y; s.inside = true; }
        if (p.id === e.pointerId) {
          const dx = e.clientX - p.x, now = e.timeStamp;
          if (!p.moved && Math.abs(dx) > 6 && Math.abs(dx) > Math.abs(e.clientY - p.y)) {
            p.moved = true; this.stop(); this.setActive(null); s.mode = DRAG; st.setPointerCapture(e.pointerId);
          }
          if (p.moved) {
            const v = (e.clientX - p.lastX) / Math.max(1, now - p.lastT);
            p.v = p.v * 0.6 + v * 0.4; p.lastX = e.clientX; p.lastT = now;
            const scale = p.lane > 0 ? 1 : 1 / g.kb;
            s.offset = p.start - p.lane * dx * scale;
            s.v = this.reduced ? 0 : -p.lane * p.v * 1000 * scale;
            this.kick();
          }
          return;
        }
        if (e.pointerType !== "mouse" || this.openIndex !== null) return;
        if (s.lock) { if (Math.hypot(at.x - s.lockX, at.y - s.lockY) < 4) return; s.lock = false; }
        this.hover(this.hitTest(at.x, at.y));
      });
      const finish = (e, cancelled) => {
        const p = this.p; if (p.id !== e.pointerId) return;
        if (st.hasPointerCapture(e.pointerId)) st.releasePointerCapture(e.pointerId);
        this.p = { ...p, id: -1 };
        if (s.mode === DRAG) {
          s.mode = RUN;
          const carry = Math.exp(-Math.max(0, e.timeStamp - p.lastT) / 70);
          s.v = this.reduced ? 0 : clamp(s.v * carry, -1400, 1400);
          if (e.pointerType === "mouse") { const at = this.local(e); s.lock = true; s.lockX = at.x; s.lockY = at.y; }
          this.kick(); return;
        }
        if (cancelled || p.moved) return;
        const touch = e.pointerType !== "mouse";
        if (p.index < 0) { if (touch && this.active !== null) { this.stop(); this.setActive(null); } return; }
        this.stop();
        if (touch && this.active !== p.index) this.setActive(p.index); else this.pendingOpen = p.index;
      };
      st.addEventListener("pointerup", (e) => finish(e, false));
      st.addEventListener("pointercancel", (e) => finish(e, true));
      st.addEventListener("pointerleave", (e) => {
        if (e.pointerType !== "mouse") return;
        s.inside = false; s.lock = false;
        const cur = this.active;
        if (this.p.id < 0 && this.openIndex === null && cur !== null && cur !== this.autoActive && !this.focusVisible()) this.setActive(null);
      });
      st.addEventListener("focusout", (e) => {
        const next = e.relatedTarget;
        if ((next && st.contains(next)) || this.openIndex !== null || s.inside) return;
        if (this.active !== null && this.active !== this.autoActive) this.setActive(null);
      });
      st.addEventListener("keydown", (e) => {
        if (!["ArrowRight", "ArrowLeft", "Home", "End"].includes(e.key) || !this.n) return;
        e.preventDefault();
        const own = e.target.closest(".k-plate");
        const from = own ? Number(own.dataset.dish) : (this.active ?? this.center);
        this.go(e.key === "Home" ? 0 : e.key === "End" ? this.n - 1 : from + (e.key === "ArrowRight" ? 1 : -1), true);
      });
      this.plates.forEach((b, i) => {
        b.addEventListener("focus", () => { if (this.p.id < 0) { this.stop(); this.setActive(i); } });
        b.addEventListener("click", (e) => { const pend = this.pendingOpen; this.pendingOpen = -1; if (e.detail === 0 || pend === i) this.open(i); });
      });
    }

    /* ----- Dialogue ----- */
    open(i) {
      this.stop();
      this.setActive(i);
      this.s.v = 0; this.s.mode = RUN;
      this.openIndex = i;
      this.paintBelt();
      this.dialog = new DishDialog(this, i);
    }
    close() {
      const i = this.openIndex;
      this.openIndex = null; this.dialog = null;
      this.kick(); this.syncAuto();
      if (i !== null) this.plates[i].focus({ preventScroll: true });
    }
    setLifted(i) {
      this.lifted = i;
      this.plates.forEach((b, j) => { b.style.visibility = j === i ? "hidden" : ""; });
      this.renderActive();
    }
  }

  class DishDialog {
    constructor(belt, index) {
      this.belt = belt; this.index = index; this.closing = false;
      const it = belt.items[index], L = belt.L, tid = `${belt.uid}-dlg`;
      const el = document.createElement("div");
      el.className = "k-dialog"; el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.setAttribute("aria-labelledby", tid);
      el.innerHTML = `
        <div class="k-backdrop" aria-hidden="true"></div>
        <div class="k-card">
          <div class="k-card-bg" aria-hidden="true"></div>
          <button type="button" class="k-close">${esc(L.close)}<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3.5 3.5l9 9M12.5 3.5l-9 9"/></svg></button>
          <div class="k-figure"><span class="k-fig-shadow" aria-hidden="true"></span>
            <span class="k-dish k-dish--big t${tierOf(it.tier)}"><img src="${it.image}" alt="${esc(it.name)}" draggable="false"></span></div>
          <div class="k-info">
            <p class="k-count"><i class="t${tierOf(it.tier)}"></i>${pad(index + 1)} / ${pad(belt.n)}${it.category ? ` · ${esc(it.category)}` : ""}</p>
            <h3 id="${tid}">${esc(it.name)}</h3>
            ${it.description ? `<p class="k-text">${esc(it.description)}</p>` : ""}
            ${it.details && it.details.length ? `<ul class="k-details">${it.details.map(d => `<li>${esc(d)}</li>`).join("")}</ul>` : ""}
            <div class="k-buy">
              <p class="k-price">${esc(it.price)}</p>
              <a class="k-order" href="${belt.o.orderHref || "#commander"}">${esc(L.order)}<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/></svg></a>
              ${it.categoryId ? `<button type="button" class="k-see">${esc(L.see)} →</button>` : ""}
            </div>
          </div>
        </div>`;
      document.body.append(el);
      this.el = el;
      this.figure = el.querySelector(".k-figure");
      this.prevOverflow = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      el.querySelector(".k-close").addEventListener("click", () => this.dismiss());
      el.querySelector(".k-backdrop").addEventListener("click", () => this.dismiss());
      const see = el.querySelector(".k-see");
      if (see) see.addEventListener("click", () => { this.dismiss(true); belt.o.onSeeCategory && belt.o.onSeeCategory(it.categoryId); });
      el.addEventListener("keydown", (e) => this.onKey(e));

      const from = belt.lifts[index].getBoundingClientRect();
      el.querySelector(".k-close").focus({ preventScroll: true });
      belt.setLifted(index);
      if (!belt.reduced && from.width > 0) {
        const to = this.figure.getBoundingClientRect();
        const sx = from.width / to.width, sy = from.height / to.height;
        const dx = from.left + from.width / 2 - (to.left + to.width / 2), dy = from.top + from.height / 2 - (to.top + to.height / 2);
        const rise = Math.min(120, Math.abs(dy) * 0.3 + 40);
        this.figure.animate([
          { transform: `translate(${dx}px, ${dy}px) scale(${sx}, ${sy})` },
          { transform: `translate(${dx * 0.42}px, ${dy * 0.42 - rise}px) scale(${((sx + 1) / 2) * 1.05}, ${((sy + 1) / 2) * 1.05}) rotate(${dx > 0 ? -6 : 6}deg)`, offset: 0.5 },
          { transform: "none" }
        ], { duration: 680, easing: "cubic-bezier(.22,.85,.3,1)" });
      }
      requestAnimationFrame(() => el.classList.add("is-shown"));
    }
    onKey(e) {
      if (e.key === "Escape") { e.preventDefault(); this.dismiss(); return; }
      if (e.key !== "Tab") return;
      const c = [...this.el.querySelectorAll("button, a[href]")];
      const first = c[0], last = c[c.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
    dismiss(instant) {
      if (this.closing) return;
      this.closing = true;
      this.el.classList.remove("is-shown");
      const belt = this.belt;
      const finish = () => {
        this.el.remove();
        document.body.style.overflow = this.prevOverflow;
        belt.setLifted(null);
        belt.close();
      };
      const to = belt.lifts[this.index].getBoundingClientRect();
      if (instant || belt.reduced || !to.width) { finish(); return; }
      const from = this.figure.getBoundingClientRect();
      const sx = to.width / from.width, sy = to.height / from.height;
      const dx = to.left + to.width / 2 - (from.left + from.width / 2), dy = to.top + to.height / 2 - (from.top + from.height / 2);
      const a = this.figure.animate([
        { transform: "none" },
        { transform: `translate(${dx * 0.58}px, ${dy * 0.58 - 36}px) scale(${(sx + 1) / 2}, ${(sy + 1) / 2})`, offset: 0.55 },
        { transform: `translate(${dx}px, ${dy}px) scale(${sx}, ${sy})` }
      ], { duration: 540, easing: "cubic-bezier(.45,0,.55,1)", fill: "forwards" });
      a.onfinish = finish;
    }
  }

  window.SushiConveyor = SushiConveyor;
})();
