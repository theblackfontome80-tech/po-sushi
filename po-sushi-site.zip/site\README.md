# PO SUSHI — site web

Site vitrine statique (HTML/CSS/JS, sans dépendance ni build) pour PO SUSHI, Av. des Orangers, Khezama — Sousse.

## Lancer en local
```
node serve.js
```
puis ouvrir http://localhost:5173

## Structure
- `index.html` — page unique : hero, spécialités, carte, plateaux, univers, galerie, commander, localisation (SEO + JSON-LD Restaurant).
- `css/styles.css` — design system (tokens sumi / washi / shu / beige), responsive, animations.
- `js/menu-data.js` — **toute la carte** (catégories, plats, prix DT, plateaux, galerie). C'est le seul fichier à modifier pour changer un prix.
- `js/app.js` — composants rendus (catégorie, ligne de plat, plateau, galerie, filtres, lightbox, menu mobile, retour en haut, statut ouvert/fermé).
- `js/conveyor.js` + `css/conveyor.css` — tapis kaiten (portage natif du composant React « SushiConveyorMenu »). Les plats affichés sur le tapis sont dans `PO_DATA.belt` ; `tier` = couleur d'assiette selon le prix.
- `assets/belt/` — photos carrées des assiettes du tapis.
- `assets/ig/` — photos publiées sur Instagram @sushipo.resto.
- `assets/menu/` — photos extraites du menu officiel PDF.

## Sources des informations
- Carte et prix : menu officiel PDF (me-qr), 19 pages.
- Adresse, téléphone, horaires, note : fiche Google Maps.
- Téléphone et livraison Zig Zag : bio et publications Instagram.

## À valider avec le restaurant avant mise en ligne
- Horaires du vendredi (Google affiche « 02:00 – 00:00 », probablement une erreur de saisie ; le site indique 11h30 – 00h00 tous les jours).
- Lien exact de l'app Zig Zag (actuellement : fiche App Store « Zigzag Delivery »).
- Fichier HD du logo et photos originales en haute définition (les images Instagram sont en 640 px et contiennent le numéro en surimpression, recadré par le CSS).
- Nom de domaine (`canonical` = sushipo.tn, à remplacer).
